//
//  AppConfig.swift
//  MonAgent
//
//  Created by Christiane Lagace on 2026-04-01.
//

import SwiftUI

enum AppConfig {
  static var cleApi: String {
    Bundle.main.infoDictionary?["CLE_API"] as? String ?? ""
  }
  
  static var urlServiceWeb: String {
    #if DEBUG
      return "https://api.cohere.com/v2/chat"
    #else
      return "https://service-a-developper.mondomaine.com"
    #endif
  }
}
