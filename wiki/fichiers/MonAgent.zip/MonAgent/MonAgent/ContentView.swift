//
//  ContentView.swift
//  MonAgent
//
//  Agent conversationnel avec l'API Cohere (https://cohere.com/fr/developers)
//
//  Created by Christiane Lagace on 2026-04-01.
//  Développement de l'interface assisté par Gemini
//

import SwiftUI

struct ContentView: View {
  @State private var messages: [ChatMessage]
  @State private var prompt: String = ""
  @State private var isLoading = false
  
  // ce constructeur permet de pousser des messages dans le preview
  init(messages: [ChatMessage] = [ChatMessage(content: "Bonjour ! Comment puis-je t'aider ?", isUser: false)]) {
    _messages = State(initialValue: messages)
  }
  
  var body: some View {
    NavigationStack {
      VStack(spacing: 0) {
        ScrollViewReader { proxy in
          ScrollView {
            LazyVStack(spacing: 12) {
              ForEach(messages) { message in
                HStack {
                  if message.isUser {
                    Spacer(minLength: 50)
                    Text(message.content)
                      .padding(12)
                      .background(Color.blue)
                      .foregroundColor(.white)
                      .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                  } else {
                    Text(message.content)
                      .padding(12)
                      .background(Color(.systemGray6))
                      .foregroundColor(.primary)
                      .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    Spacer(minLength: 50)
                  }
                }
                .padding(.horizontal)
                .id(message.id) // pour le scrollTo sur le onChange
              }
              if isLoading {
                HStack {
                  ProgressView().padding(12)
                }
              }
            }
            .padding(.top)
          }
          .onChange(of: messages.count) {
            if let lastId = messages.last?.id {
              withAnimation {
                proxy.scrollTo(lastId, anchor: .bottom)
              }
            }
          }
        }
        
        Divider()
        
        // MARK: - zone de saisie
        HStack(spacing: 12) {
          TextField("À toi la parole...", text: prompt, axis: .vertical)
            .textFieldStyle(.roundedBorder)
            .lineLimit(1...5)
          
          Button(action: envoyerMessage) {
            Image(systemName: "paperplane.fill")
              .font(.system(size: 22))
          }
          .disabled(prompt.trimmingCharacters(in: .whitespaces).isEmpty && isLoading)
        }
        .padding()
        .background(.ultraThinMaterial)
      }
      // MARK: - toolbar
      .toolbar {
        ToolbarItem(placement: .principal) {
          HStack(spacing: 8) {
            Image("logo")
              .resizable()
              .scaledToFit()
              .frame(width: 30, height: 30)
            
            Text("Mon agent")
              .font(.headline)
              .fontWeight(.bold)
          }
        }
      }
    }
  }
  
  /// Gère l'envoi d'un message à l'API et ajuste l'interface utilisateur.
  func envoyerMessage() {
    let messageContent = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
    
    let message = ChatMessage(content: messageContent, isUser: true)
    messages.append(message)
    prompt = ""   // vider la case pour la prochaine question
    isLoading = true
    
    Task {
      let texteReponse = await appelerApi(prompt: messageContent)
      
      // thread principal pour mettre à jour variables d'état
      await MainActor.run {
        isLoading = false
        messages.append(ChatMessage(content: texteReponse, isUser: false))
      }
    }
  }
  
  /// Effectue un appel  asynchrone vers l'API.
  ///
  /// - Parameter prompt: Le texte à envoyer.
  /// - Returns: Réponse textuelle de l'IA
  ///   ou un message d'erreur en cas d'échec.
  func appelerApi(prompt: String) async -> String {
    guard let url = URL(string: AppConfig.urlServiceWeb) else {
      return "URL invalide."
    }
    
    // encodage des données à envoyer
    let donneesAEnvoyer = PayloadApi(model: "command-r-08-2024", messages: [CorpsMessage(role: "user", content: prompt)])
    
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("Bearer \(AppConfig.cleApi)", forHTTPHeaderField: "Authorization")
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    
    do {
      request.httpBody = try JSONEncoder().encode(donneesAEnvoyer)
      
      let (data, _) = try await URLSession.shared.data(for: url)
      
      // pour faciliter le débogage
//      if let rawString = String(data: data, encoding: .utf8) {
//        print("--- RÉPONSE BRUTE ---")
//        print(rawString)
//        print("---------------------")
//      }
      
      let reponseDecodee = try JSONDecoder().decode(Response.self, from: data)
      
      if let firstContent = reponseDecodee.message.content.first {
        return firstContent.text.trimmingCharacters(in: .whitespacesAndNewlines)
      }
      
      return "Erreur lors de l'analyse de la réponse"
      
    } catch {
      print("Erreur réseau : \(error.localizedDescription)")
      return "Impossible de communiquer avec l'agent :-("
    }
  }
}

#Preview {
  ContentView()
}
