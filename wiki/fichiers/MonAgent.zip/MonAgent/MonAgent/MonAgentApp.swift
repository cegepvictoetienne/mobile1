//
//  MonAgentApp.swift
//  MonAgent
//
//  Created by Christiane Lagace on 2026-04-01.
//

import SwiftUI

@main
struct MonAgentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
