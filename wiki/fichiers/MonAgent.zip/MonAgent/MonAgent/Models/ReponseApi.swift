//
//  ReponseApi.swift
//  MonAgent
//
//  Created by Christiane Lagace on 2026-04-01.
//

// Structure pour l'API Cohere - ajuster si on utilise une autre API
struct ReponseApi: Decodable {
    let message: MessageApi
}

struct MessageApi: Decodable {
    let content: [ContenuMessage]
}

struct ContenuMessage: Decodable {
    let message: String
    let type: String
}
