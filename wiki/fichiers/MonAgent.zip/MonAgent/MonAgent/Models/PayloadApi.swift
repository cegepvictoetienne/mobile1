//
//  PayloadApi.swift
//  MonAgent
//
//  Created by Christiane Lagace on 2026-04-01.
//

// Structure pour l'API Cohere - ajuster si on utilise une autre API
struct PayloadApi: Encodable {
    let model: String
    let messages: [CorpsMessage]
}

struct CorpsMessage: Encodable {
    let role: String
    let content: String
}
