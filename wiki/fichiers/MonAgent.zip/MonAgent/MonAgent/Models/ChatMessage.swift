//
//  ChatMessage.swift
//  MonAgent
//
//  Created by Christiane Lagace on 2026-04-01.
//  Inspiré de https://www.holdapp.com/blog/ai-apps-swiftui-with-openai-api
//
import SwiftUI

struct ChatMessage {
  let id = UUID()
  let content: String
  let isUser: Bool
}

